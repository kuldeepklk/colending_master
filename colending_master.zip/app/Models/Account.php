<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Account extends Model
{
    protected $connection = 'mysql_cbs'; // Use the secondary DB
    protected $table = 'accounts';
    protected $guarded = [];
    use HasFactory;
}
