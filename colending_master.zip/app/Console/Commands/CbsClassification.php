<?php

namespace App\Console\Commands;

use App\Models\Account;
use Illuminate\Console\Command;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class CbsClassification extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cbs:classification';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        //** Capri */
        $loans = DB::connection('mysql_capri')->table('loan_accounts')
            ->select('loan_account_number', DB::raw('SUM(bank_sanction_amount) as total_sanction_amount'), 'classification')
            ->where('classification', 'NPA')
            ->groupBy('loan_account_number', 'classification') // Ensure classification is in GROUP BY
            ->get();

        $arr = array();
        foreach ($loans as $loan) {
            //*** */
            $collection = DB::connection('mysql_capri')->table('collections')
                ->whereIn('REQ_NUMBER', function ($query) use ($loan) {
                    $query->select('mfl_ref_no')
                        ->from('loan_accounts')
                        ->where('classification', 'NPA')
                        ->where('loan_account_number', $loan->loan_account_number);
                })
                ->selectRaw('SUM(bank_principal) as total_principal, SUM(bank_interest) as total_interest')
                ->first();

            $totalInterest = DB::connection('mysql_capri')->table('interests')
                ->whereIn('loan_id', function ($query) use ($loan) {
                    $query->select('loan_id')
                        ->from('loan_accounts')
                        ->where('classification', 'NPA')
                        ->where('loan_account_number', $loan->loan_account_number);
                })
                ->selectRaw('SUM(bank_interest) as total_interest')
                ->first();


            //dd($loan->loan_account_number, $collection);
            $principal_outstanding = round($loan->total_sanction_amount - $collection->total_principal, 2);
            $interest_outstanding = round($totalInterest->total_interest - $collection->total_interest, 2);
            $arr[] = ([
                'loan_account_number' => $loan->loan_account_number,
                'sanction_amount' => $loan->total_sanction_amount,
                'principal_collection' => $collection->total_principal,
                'interest_collection' => $collection->total_interest,
                'interest_due' => (float)$totalInterest->total_interest,
                'principal_outstanding' => $principal_outstanding,
                'interest_outstanding' => $interest_outstanding,
                'total_outstanding' => $principal_outstanding + $interest_outstanding
            ]);
            Account::create([
                'entry_date' => date("Y-m-d"),
                'loan_account_number' => $loan->loan_account_number,
                'sanction_amount' => $loan->total_sanction_amount,
                'principal_collection' => $collection->total_principal,
                'interest_collection' => $collection->total_interest,
                'interest_due' => (float)$totalInterest->total_interest,
                'principal_outstanding' => $principal_outstanding,
                'interest_outstanding' => $interest_outstanding,
                'total_outstanding' => $principal_outstanding + $interest_outstanding
            ]);
        }

        //*** Muthoot Gold */
        $muthoot_loans = DB::connection('mysql_muthoot')->table('loan_accounts')
            ->select('loan_account_number', DB::raw('SUM(bank_sanction_amount) as total_sanction_amount'), 'classification')
            ->where('classification', 'NPA')
            ->groupBy('loan_account_number', 'classification') // Ensure classification is in GROUP BY
            ->get();
        //dd($muthoot_loans);
        $arr = array();
        foreach ($muthoot_loans as $muthoot_loan) {
            //*** */
            $collection = DB::connection('mysql_muthoot')->table('collections')
                ->whereIn('REQ_NUMBER', function ($query) use ($muthoot_loan) {
                    $query->select('mfl_ref_no')
                        ->from('loan_accounts')
                        ->where('classification', 'NPA')
                        ->where('loan_account_number', $muthoot_loan->loan_account_number);
                })
                ->selectRaw('SUM(bank_principal) as total_principal, SUM(bank_interest) as total_interest')
                ->first();

            $totalInterest = DB::connection('mysql_muthoot')->table('interests')
                ->whereIn('loan_id', function ($query) use ($muthoot_loan) {
                    $query->select('loan_id')
                        ->from('loan_accounts')
                        ->where('classification', 'NPA')
                        ->where('loan_account_number', $muthoot_loan->loan_account_number);
                })
                ->selectRaw('SUM(bank_interest) as total_interest')
                ->first();


            //dd($muthoot_loan->loan_account_number, $collection);
            $principal_outstanding = round($muthoot_loan->total_sanction_amount - $collection->total_principal, 2);
            $interest_outstanding = round($totalInterest->total_interest - $collection->total_interest, 2);
            $arr[] = ([
                'loan_account_number' => $muthoot_loan->loan_account_number,
                'sanction_amount' => $muthoot_loan->total_sanction_amount,
                'principal_collection' => $collection->total_principal,
                'interest_collection' => $collection->total_interest,
                'interest_due' => (float)$totalInterest->total_interest,
                'principal_outstanding' => $principal_outstanding,
                'interest_outstanding' => $interest_outstanding,
                'total_outstanding' => $principal_outstanding + $interest_outstanding
            ]);
            Account::create([
                'entry_date' => date("Y-m-d"),
                'loan_account_number' => $muthoot_loan->loan_account_number,
                'sanction_amount' => $muthoot_loan->total_sanction_amount,
                'principal_collection' => $collection->total_principal,
                'interest_collection' => $collection->total_interest,
                'interest_due' => (float)$totalInterest->total_interest,
                'principal_outstanding' => $principal_outstanding,
                'interest_outstanding' => $interest_outstanding,
                'total_outstanding' => $principal_outstanding + $interest_outstanding
            ]);
        }


        /*** Muthoot MSME */
        $muthoot_msme_loans = DB::connection('mysql_muthoot_msme')->table('loan_accounts')
            ->select('loan_account_number', DB::raw('SUM(bank_sanction_amount) as total_sanction_amount'), 'classification')
            ->where('classification', 'NPA')
            ->groupBy('loan_account_number', 'classification') // Ensure classification is in GROUP BY
            ->get();
        //dd($muthoot_msme_loans);
        $arr = array();
        foreach ($muthoot_msme_loans as $muthoot_msme_loan) {
            //***** */
            $collection = DB::connection('mysql_muthoot_msme')->table('collections')
                ->whereIn('REQ_NUMBER', function ($query) use ($muthoot_msme_loan) {
                    $query->select('mfl_ref_no')
                        ->from('loan_accounts')
                        ->where('classification', 'NPA')
                        ->where('loan_account_number', $muthoot_msme_loan->loan_account_number);
                })
                ->selectRaw('SUM(bank_principal) as total_principal, SUM(bank_interest) as total_interest')
                ->first();

            $totalInterest = DB::connection('mysql_muthoot_msme')->table('interests')
                ->whereIn('loan_id', function ($query) use ($muthoot_msme_loan) {
                    $query->select('loan_id')
                        ->from('loan_accounts')
                        ->where('classification', 'NPA')
                        ->where('loan_account_number', $muthoot_msme_loan->loan_account_number);
                })
                ->selectRaw('SUM(bank_interest) as total_interest')
                ->first();


            //dd($muthoot_msme_loan->loan_account_number, $collection);
            $principal_outstanding = round($muthoot_msme_loan->total_sanction_amount - $collection->total_principal, 2);
            $interest_outstanding = round($totalInterest->total_interest - $collection->total_interest, 2);
            $arr[] = ([
                'loan_account_number' => $muthoot_msme_loan->loan_account_number,
                'sanction_amount' => $muthoot_msme_loan->total_sanction_amount,
                'principal_collection' => $collection->total_principal,
                'interest_collection' => $collection->total_interest,
                'interest_due' => (float)$totalInterest->total_interest,
                'principal_outstanding' => $principal_outstanding,
                'interest_outstanding' => $interest_outstanding,
                'total_outstanding' => $principal_outstanding + $interest_outstanding
            ]);
            Account::create([
                'entry_date' => date("Y-m-d"),
                'loan_account_number' => $muthoot_msme_loan->loan_account_number,
                'sanction_amount' => $muthoot_msme_loan->total_sanction_amount,
                'principal_collection' => $collection->total_principal,
                'interest_collection' => $collection->total_interest,
                'interest_due' => (float)$totalInterest->total_interest,
                'principal_outstanding' => $principal_outstanding,
                'interest_outstanding' => $interest_outstanding,
                'total_outstanding' => $principal_outstanding + $interest_outstanding
            ]);
        }

        return 0;
    }
}
